package com.clinexa.appointment;

import com.clinexa.User.User;
import com.clinexa.appointment.dto.AppointmentRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/appointments")
@RequiredArgsConstructor
public class AppointmentController {

    private final AppointmentService service;

    @PostMapping
    @PreAuthorize("hasAnyAuthority('PATIENT','RECEPTIONIST','ADMIN')")
    public Appointment book(
            @RequestBody AppointmentRequest req,
            Authentication authentication
    ) {

        // ✅ Logged-in user's email from JWT
        String email = authentication.getName();

        return service.book(email, req);
    }

    @PutMapping("/appointments/{id}/doctor-status")
    @PreAuthorize("hasRole('DOCTOR')")
    public Appointment updateStatusByDoctor(
            @PathVariable Long id,
            @RequestParam AppointmentStatus status,
            @AuthenticationPrincipal User loggedInDoctor
    ) {
        return service.updateStatusByDoctor(
                id,
                status,
                loggedInDoctor
        );
    }

    @PutMapping("/appointments/{id}/cancel")
    @PreAuthorize("hasRole('RECEPTIONIST')")
    public Appointment cancelAppointment(
            @PathVariable Long id
    ) {
        return service.cancelAppointment(id);
    }

    @PutMapping("/appointments/my/{id}/cancel")
    @PreAuthorize("hasRole('PATIENT')")
    public Appointment cancelOwnAppointment(
            @PathVariable Long id,
            @AuthenticationPrincipal User loggedInPatient
    ) {
        return service.cancelOwnAppointment(
                id,
                loggedInPatient
        );
    }

}